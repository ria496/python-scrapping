cd ../var/wwww/html/python/scraping 
python write_file.py