f = open("log_file1.txt", "a")
f.write("test 2")
f.close()