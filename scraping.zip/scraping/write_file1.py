from datetime import datetime

now = datetime.now()

current_time = now.strftime("%H:%M:%S")
print("Current Time =", current_time)

f = open("log_file1.txt", "a")
f.write("\n"+current_time)
f.close()