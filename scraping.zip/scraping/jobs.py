from urllib.request import Request, urlopen
from bs4 import BeautifulSoup as soup
from datetime import datetime, timedelta, date
import requests
import json
import config

url = 'https://www.khmer24.com/en/jobs/all-jobs.html'
req = Request(url , headers={'User-Agent': 'Mozilla/5.0'})

webpage = urlopen(req).read()
page_soup = soup(webpage, "html.parser")

b = ""

today = datetime.today().strftime('%Y-%m-%d')
yesterday = datetime.now() - timedelta(1)
yesterday = datetime.strftime(yesterday, '%Y-%m-%d')
print(today)
print(yesterday)

title = page_soup.find('h2', class_='title')

if title != None:
	last_page = (title.text).split(" Result")[0]
	print(last_page)
else:
	last_page = 0


def scrapDetails(weblink, itemCount):
	page_link = weblink + str(itemCount)

	reqt = Request(page_link , headers={'User-Agent': 'Mozilla/5.0'})

	full_webpage = urlopen(reqt).read()
	full_page_soup = soup(full_webpage, "html.parser")

	item_lis = full_page_soup.find_all('li', class_='item')
	

	for x in range(0,len(item_lis) - 1):
		item_details_arr = []
		item_details = []
		row = False


		article_link = item_lis[x].find('a')['href']
		article = item_lis[x].find('article')
		summary = article.find('ul', class_='summary')
		item_fields = article.find('ul', class_='item-fields')
		li_date = summary.find('li', class_='date')
		posted_at = li_date.find('time').text


		if (posted_at.find('ago') != -1) or posted_at.strip() == 'Just now': 
			item_title = article.find('h2', class_='item-title').text
			company_name = summary.find('li', class_='company-name').text
			location = summary.find('li', class_='location').text

			if item_fields != None:
				fields_all_li = item_fields.find_all('li')
			else:
				fields_all_li = ""

			category = ""
			job_type = ""
			experience = ""
			sal_start_from = ""

			if fields_all_li != None and fields_all_li != "":
				for i in range(0, len(fields_all_li)):
					each_div = fields_all_li[i].find('div')
					key_span = each_div.find('span', class_='title').text
					value_span = each_div.find('span', class_='value').text

					if key_span.strip() == 'Category':
						category = value_span


					if key_span.strip() == 'Job Type':
						job_type = value_span

					if key_span.strip() == 'Experience':
						experience = value_span

					if key_span.strip() == 'Salary Start From':
						sal_start_from = value_span

			item_details.append(category)
			item_details.append(item_title)
			item_details.append(article_link)
			item_details.append(company_name)
			item_details.append(job_type)
			item_details.append(experience)
			item_details.append(sal_start_from)
			item_details.append(location)
			item_details.append(today)

			item_details_arr.append(item_details)
			row = True

		# elif posted_at.strip() == 'Yesterday':
		# 	item_title = article.find('h2', class_='item-title').text
		# 	company_name = summary.find('li', class_='company-name').text
		# 	location = summary.find('li', class_='location').text

		# 	if item_fields != None:
		# 		fields_all_li = item_fields.find_all('li')
		# 	else:
		# 		fields_all_li = ""


		# 	category = ""
		# 	job_type = ""
		# 	experience = ""
		# 	sal_start_from = ""

		# 	if fields_all_li != None and fields_all_li != "":
		# 		for i in range(0, len(fields_all_li)):
		# 			each_div = fields_all_li[i].find('div')
		# 			key_span = each_div.find('span', class_='title').text
		# 			value_span = each_div.find('span', class_='value').text

		# 			if key_span.strip() == 'Category':
		# 				category = value_span


		# 			if key_span.strip() == 'Job Type':
		# 				job_type = value_span

		# 			if key_span.strip() == 'Experience':
		# 				experience = value_span

		# 			if key_span.strip() == 'Salary Start From':
		# 				sal_start_from = value_span

		# 	item_details.append(category)
		# 	item_details.append(item_title)
		# 	item_details.append(article_link)
		# 	item_details.append(company_name)
		# 	item_details.append(job_type)
		# 	item_details.append(experience)
		# 	item_details.append(sal_start_from)
		# 	item_details.append(location)
		# 	item_details.append(yesterday)

		# 	item_details_arr.append(item_details)
		# 	row = True
		# else:
		# 	posted_at_day = posted_at.split("-")[0]
		# 	posted_at_year = posted_at.split("-")[2]
		# 	month_name = posted_at.split("-")[1]
		# 	datetime_object = datetime.strptime(month_name, "%b")
		# 	month_number = datetime_object.month
			
		# 	f_date = date(int(posted_at_year), month_number, int(posted_at_day))
		# 	l_date = date(datetime.today().year, datetime.today().month, datetime.today().day)
		# 	delta = l_date - f_date
			
		# 	if delta.days < 15:
		# 		item_title = article.find('h2', class_='item-title').text
		# 		company_name = summary.find('li', class_='company-name').text
		# 		location = summary.find('li', class_='location').text

		# 		if item_fields != None:
		# 			fields_all_li = item_fields.find_all('li')
		# 		else:
		# 			fields_all_li = ""


		# 		category = ""
		# 		job_type = ""
		# 		experience = ""
		# 		sal_start_from = ""

		# 		if fields_all_li != None and fields_all_li != "":
		# 			for i in range(0, len(fields_all_li)):
		# 				each_div = fields_all_li[i].find('div')
		# 				key_span = each_div.find('span', class_='title').text
		# 				value_span = each_div.find('span', class_='value').text

		# 				if key_span.strip() == 'Category':
		# 					category = value_span


		# 				if key_span.strip() == 'Job Type':
		# 					job_type = value_span

		# 				if key_span.strip() == 'Experience':
		# 					experience = value_span

		# 				if key_span.strip() == 'Salary Start From':
		# 					sal_start_from = value_span

		# 		item_details.append(category)
		# 		item_details.append(item_title)
		# 		item_details.append(article_link)
		# 		item_details.append(company_name)
		# 		item_details.append(job_type)
		# 		item_details.append(experience)
		# 		item_details.append(sal_start_from)
		# 		item_details.append(location)
		# 		item_details.append(posted_at_year+"-"+str(month_number)+"-"+posted_at_day)

		# 		item_details_arr.append(item_details)
		# 		row = True
		

		if row:
			print(item_details_arr)
			url = config.url
			data = json.dumps(item_details_arr )
			sheet_name = "jobs"
			payload = "{\"Article_Link\": "+data+" ,  \"sheet_name\" : \""+sheet_name+"\"}"
			headers = {
			    'content-type': "application/json",
			    'cache-control': "no-cache",
			    'postman-token': "110bf2c8-7f1a-bc87-4f12-0db56c28d057"
			    }

			response = requests.request("POST", url, data=payload, headers=headers)

	if itemCount < int(last_page):
		itemCount = itemCount + 50
		scrapDetails(weblink, itemCount)

scrapDetails("https://www.khmer24.com/en/ajax/get-job-items?category=jobs&per_page=", 0)

