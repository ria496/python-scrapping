from urllib.request import Request, urlopen
from bs4 import BeautifulSoup as soup
# import datetime 
from datetime import datetime, timedelta, date
import requests
import json
import config

url = 'https://www.khmer24.com/en/c-tvs-videos-and-audios.html'

req = Request(url , headers={'User-Agent': 'Mozilla/5.0'})

webpage = urlopen(req).read()
page_soup = soup(webpage, "html.parser")
page_list = page_soup.find_all('a', class_='page-link')

last_page = page_list[-1]["href"].split("=")[1]

print(last_page)

b = ""
# today = datetime.today().strftime('%m-%d-%Y')

today = datetime.today().strftime('%Y-%m-%d')
yesterday = datetime.now() - timedelta(1)
yesterday = datetime.strftime(yesterday, '%Y-%m-%d')
print(today)
print(yesterday)


def scrapDetails(weblink, itemCount):
	page_link = weblink + str(itemCount)

	reqt = Request(page_link , headers={'User-Agent': 'Mozilla/5.0'})

	full_webpage = urlopen(reqt).read()
	full_page_soup = soup(full_webpage, "html.parser")

	item_titles = full_page_soup.find_all('h2', class_='item-title')
	item_links = full_page_soup.find_all('a', class_='post')
	item_description = full_page_soup.find_all('p', class_='description')
	item_posted_at = full_page_soup.find_all('time')

	for x in range(0,len(item_titles) - 1):
		item_details_arr = []
		item_details = []
		word = item_posted_at[x].text
		row = False

		if (word.find('ago') != -1) or word.strip() == 'Just now': 
			item_details.append(item_titles[x].text)
			item_details.append(item_links[x]["href"])
			
			# tel = (item_description[x].text).split("tel:")[1]
			# phones = tel.split(",")
			# phone1 = phones[0]
			# phone2 = phones[1] if len(phones)>1 else b
			# phone3 = phones[2] if len(phones)>2 else b
			# phone1 = "0"+phone1 if len(phone1)==8 else phone1
			# phone2 = "0"+phone2 if len(phone2)==8 else phone2
			# phone3 = "0"+phone3 if len(phone3)==8 else phone3
			# item_details.append(phone1)
			# item_details.append(phone2)
			# item_details.append(phone3)
			
					
			single_item_link = (item_links[x]["href"]).replace('https', 'http', 1)
			# print(single_item_link)
			
			r = requests.get(single_item_link, headers={'User-Agent': 'Mozilla/5.0'})
			item_info = soup(r.content, "html.parser")
			
			numbers = item_info.find("div", class_= 'list_numbers')
			if numbers == None:
				phone1 = b 
				phone2 = b 
				phone3 = b
				item_details.append(phone1)
				item_details.append(phone2)
				item_details.append(phone3)
			else:
				list_numbers = numbers.find_all("div", class_= 'num')
				phone1 = list_numbers[0].text
				phone2 = list_numbers[1].text if len(list_numbers)>1 else b
				phone3 = list_numbers[2].text if len(list_numbers)>2 else b
				phone1 = "0"+phone1 if len(phone1)==8 else phone1
				phone2 = "0"+phone2 if len(phone2)==8 else phone2
				phone3 = "0"+phone3 if len(phone3)==8 else phone3
				item_details.append(phone1)
				item_details.append(phone2)
				item_details.append(phone3)

			location_span = item_info.find("span", class_= 'icon-location')
			# print(location_span)
			
			
			if location_span == None:
				location = ""
			else:
				location = (location_span.parent.text).replace('\n', '', 1)

			item_details.append(location)

			profile_link_ele = item_info.find("a", class_= 'header')

			if profile_link_ele == None:
				profile_link = ""
			else:
				profile_link = item_info.find("a", class_= 'header')["href"]

			item_details.append(profile_link)

			item_details.append(today)

			item_details_arr.append(item_details)
			row = True
		# elif word.strip() == 'Yesterday':
		# 	item_details.append(item_titles[x].text)
		# 	item_details.append(item_links[x]["href"])
			
		# 	# tel = (item_description[x].text).split("tel:")[1]
		# 	# phones = tel.split(",")
		# 	# phone1 = phones[0]
		# 	# phone2 = phones[1] if len(phones)>1 else b
		# 	# phone3 = phones[2] if len(phones)>2 else b
		# 	# phone1 = "0"+phone1 if len(phone1)==8 else phone1
		# 	# phone2 = "0"+phone2 if len(phone2)==8 else phone2
		# 	# phone3 = "0"+phone3 if len(phone3)==8 else phone3
		# 	# item_details.append(phone1)
		# 	# item_details.append(phone2)
		# 	# item_details.append(phone3)
			
					
		# 	single_item_link = (item_links[x]["href"]).replace('https', 'http', 1)
		# 	# print(single_item_link)
			
		# 	r = requests.get(single_item_link, headers={'User-Agent': 'Mozilla/5.0'})
		# 	item_info = soup(r.content, "html.parser")
			
		# 	numbers = item_info.find("div", class_= 'list_numbers')
		# 	if numbers == None:
		# 		phone1 = b 
		# 		phone2 = b 
		# 		phone3 = b
		# 		item_details.append(phone1)
		# 		item_details.append(phone2)
		# 		item_details.append(phone3)
		# 	else:
		# 		list_numbers = numbers.find_all("div", class_= 'num')
		# 		phone1 = list_numbers[0].text
		# 		phone2 = list_numbers[1].text if len(list_numbers)>1 else b
		# 		phone3 = list_numbers[2].text if len(list_numbers)>2 else b
		# 		phone1 = "0"+phone1 if len(phone1)==8 else phone1
		# 		phone2 = "0"+phone2 if len(phone2)==8 else phone2
		# 		phone3 = "0"+phone3 if len(phone3)==8 else phone3
		# 		item_details.append(phone1)
		# 		item_details.append(phone2)
		# 		item_details.append(phone3)

		# 	location_span = item_info.find("span", class_= 'icon-location')
		# 	# print(location_span)
			
			
		# 	if location_span == None:
		# 		location = ""
		# 	else:
		# 		location = (location_span.parent.text).replace('\n', '', 1)

		# 	item_details.append(location)

		# 	item_details.append(yesterday)

		# 	item_details_arr.append(item_details)
		# 	row = True
		# else:
		# 	posted_at_day = word.split("-")[0]
		# 	posted_at_year = word.split("-")[2]
		# 	month_name = word.split("-")[1]
		# 	datetime_object = datetime.strptime(month_name, "%b")
		# 	month_number = datetime_object.month
			
		# 	f_date = date(int(posted_at_year), month_number, int(posted_at_day))
		# 	l_date = date(datetime.today().year, datetime.today().month, datetime.today().day)
		# 	delta = l_date - f_date
		# 	# print(delta.days)

		# 	if delta.days < 7:
		# 		item_details.append(item_titles[x].text)
		# 		item_details.append(item_links[x]["href"])
				
		# 		# tel = (item_description[x].text).split("tel:")[1]
		# 		# phones = tel.split(",")
		# 		# phone1 = phones[0]
		# 		# phone2 = phones[1] if len(phones)>1 else b
		# 		# phone3 = phones[2] if len(phones)>2 else b
		# 		# phone1 = "0"+phone1 if len(phone1)==8 else phone1
		# 		# phone2 = "0"+phone2 if len(phone2)==8 else phone2
		# 		# phone3 = "0"+phone3 if len(phone3)==8 else phone3
		# 		# item_details.append(phone1)
		# 		# item_details.append(phone2)
		# 		# item_details.append(phone3)
				
								
		# 		single_item_link = (item_links[x]["href"]).replace('https', 'http', 1)
		# 		# print(single_item_link)
				
		# 		r = requests.get(single_item_link, headers={'User-Agent': 'Mozilla/5.0'})
		# 		item_info = soup(r.content, "html.parser")
				
		# 		numbers = item_info.find("div", class_= 'list_numbers')
		# 		if numbers == None:
		# 			phone1 = b 
		# 			phone2 = b 
		# 			phone3 = b
		# 			item_details.append(phone1)
		# 			item_details.append(phone2)
		# 			item_details.append(phone3)
		# 		else:
		# 			list_numbers = numbers.find_all("div", class_= 'num')
		# 			phone1 = list_numbers[0].text
		# 			phone2 = list_numbers[1].text if len(list_numbers)>1 else b
		# 			phone3 = list_numbers[2].text if len(list_numbers)>2 else b
		# 			phone1 = "0"+phone1 if len(phone1)==8 else phone1
		# 			phone2 = "0"+phone2 if len(phone2)==8 else phone2
		# 			phone3 = "0"+phone3 if len(phone3)==8 else phone3
		# 			item_details.append(phone1)
		# 			item_details.append(phone2)
		# 			item_details.append(phone3)
				
		# 		location_span = item_info.find("span", class_= 'icon-location')
		# 		# print(location_span)
				
				
		# 		if location_span == None:
		# 			location = ""
		# 		else:
		# 			location = (location_span.parent.text).replace('\n', '', 1)

		# 		item_details.append(location)

		# 		item_details.append(posted_at_year+"-"+str(month_number)+"-"+posted_at_day)

		# 		item_details_arr.append(item_details)
		# 		row = True

		if row:
			print(item_details_arr)
			url = config.url

			data = json.dumps(item_details_arr )
			sheet_name = "tvs-videos-and-audios"
			payload = "{\"Article_Link\": "+data+" , \"sheet_name\" : \""+sheet_name+"\"}"
			headers = {
			    'content-type': "application/json",


			    'cache-control': "no-cache",
			    'postman-token': "110bf2c8-7f1a-bc87-4f12-0db56c28d057"
			    }

			response = requests.request("POST", url, data=payload, headers=headers)

	if itemCount < int(last_page):
		itemCount = itemCount + 50
		scrapDetails(weblink, itemCount)

scrapDetails("https://www.khmer24.com/en/c-tvs-videos-and-audios.html?per_page=", 50)



# item_titles = page_soup.find_all('h2', class_='item-title')
# item_links = page_soup.find_all('a', class_='post')

# # print(results)

# for i in range(0, len(item_titles)):
# 	print(item_titles[i].text)
# 	print(item_links[i]["href"])
# 	if i == 2:
# 		break
